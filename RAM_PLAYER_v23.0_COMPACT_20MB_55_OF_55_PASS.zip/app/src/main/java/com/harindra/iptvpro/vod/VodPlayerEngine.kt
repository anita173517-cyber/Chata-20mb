package com.harindra.iptvpro.vod

/**
 * RAM PLAYER v22.0 ULTIMATE — Engine-Agnostic VOD Playback Abstraction.
 *
 * Completely decouples the Cinematic VOD Player UI and controllers from any specific
 * underlying decoder SDK. Primary production implementation: [LibVlcVodPlayerEngine].
 * Live TV continues to run independently on Media3 ExoPlayer in PlayerActivity.
 */
enum class VodDecoderMode(val id: String, val label: String, val description: String) {
    AUTO_HW_FALLBACK("AUTO", "Auto (HW + SW Fallback)", "Hardware decoding with automatic software fallback"),
    HARDWARE_ONLY("HW", "Hardware Accelerated", "Lowest CPU & battery usage on supported codecs"),
    SOFTWARE_ONLY("SW", "Software (FFmpeg/avcodec)", "Maximum compatibility for tricky MKV/HEVC/10-bit files");

    fun next(): VodDecoderMode {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }

    companion object {
        fun fromId(id: String?): VodDecoderMode {
            return values().firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) } ?: AUTO_HW_FALLBACK
        }
    }
}

enum class VodBufferProfile(val id: String, val label: String, val networkCachingMs: Int, val fileCachingMs: Int) {
    FAST_START("FAST", "Fast Start (2.5s • 512MB TV)", 2500, 2000),
    CINEMA_BALANCED("BALANCED", "Cinema Balanced (5.0s)", 5000, 3500),
    ULTRA_ANTI_BUFFER("ULTRA", "Ultra Anti-Buffer (10.0s Cushion)", 10000, 6000);

    fun next(): VodBufferProfile {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }

    companion object {
        fun fromId(id: String?): VodBufferProfile {
            return values().firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) } ?: CINEMA_BALANCED
        }
    }
}

enum class VodDialoguePreset(val id: String, val label: String, val volumePercent: Int, val preampDb: Float, val voiceMidBoostDb: Float) {
    NORMAL("NORMAL", "Normal (Studio Flat)", 100, 0f, 0f),
    VOICE_CLARITY("VOICE", "Voice Clarity (+3dB Vocal)", 115, 2.0f, 4.5f),
    CINEMA_DIALOGUE("CINEMA", "Cinema Dialogue Boost (+6dB)", 130, 4.0f, 6.5f),
    NIGHT_WHISPER("NIGHT", "Night Whisper (Soft Bass + Clear Voice)", 110, 1.5f, 5.0f);

    fun next(): VodDialoguePreset {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }

    companion object {
        fun fromId(id: String?): VodDialoguePreset {
            return values().firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) } ?: NORMAL
        }
    }
}

data class VodEngineTrack(
    val id: Int,
    val name: String,
    val isSelected: Boolean = false,
    val isOffOption: Boolean = false
)

data class VodEngineVideoInfo(
    val width: Int = 0,
    val height: Int = 0,
    val fps: Float = 0f,
    val codec: String = "",
    val bitrateBps: Int = 0,
    val decoderModeLabel: String = "HW"
) {
    fun resolutionLabel(): String {
        return if (height > 0) VodTrackSelectionManager.formatResolutionLabel(height) else "Auto"
    }
}

interface VodEngineCallbacks {
    fun onOpening()
    fun onBuffering(percent: Float)
    fun onPlaying()
    fun onPaused()
    fun onTimeChanged(positionMs: Long)
    fun onLengthChanged(durationMs: Long)
    fun onSeekableChanged(seekable: Boolean)
    fun onTracksUpdated()
    fun onEnded()
    fun onError(message: String)
}

interface VodPlayerEngine {
    val engineName: String
    fun initialize(decoderMode: VodDecoderMode, bufferProfile: VodBufferProfile)
    fun setCallbacks(callbacks: VodEngineCallbacks?)
    fun loadMedia(
        streamUrl: String,
        resumePositionMs: Long,
        externalSubtitleUrl: String = "",
        headers: Map<String, String> = emptyMap()
    ): Boolean
    fun play()
    fun pause()
    fun stop()
    fun isPlaying(): Boolean
    fun isSeekable(): Boolean
    fun getPositionMs(): Long
    fun getDurationMs(): Long
    fun getBufferedPercent(): Float
    fun seekTo(positionMs: Long)
    fun setPlaybackSpeed(rate: Float)
    fun getPlaybackSpeed(): Float
    fun setVolumePercent(percent: Int)
    fun getVolumePercent(): Int
    fun setAudioDelayMs(delayMs: Long)
    fun getAudioDelayMs(): Long
    fun setSubtitleDelayMs(delayMs: Long)
    fun getSubtitleDelayMs(): Long
    fun getAudioTracks(): List<VodEngineTrack>
    fun selectAudioTrack(trackId: Int): Boolean
    fun getSubtitleTracks(): List<VodEngineTrack>
    fun selectSubtitleTrack(trackId: Int): Boolean
    fun addExternalSubtitle(subtitleUrl: String): Boolean
    fun getVideoTracks(): List<VodEngineTrack>
    fun selectVideoTrack(trackId: Int): Boolean
    fun getVideoInfo(): VodEngineVideoInfo
    fun setAspectRatio(mode: VodAspectRatioMode)
    fun applyDialoguePreset(preset: VodDialoguePreset)
    fun release()
}
