package com.harindra.iptvpro

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Independent Per-Profile & Per-Playlist WorkManager Refresh Worker for RAM PLAYER v20.0.
 *
 * - Each profile/playlist owns its own unique WorkManager job (`uniqueWorkName(profileId, playlistId)`).
 * - Refreshes the exact requested `profileId` passed via Worker input Data (never blindly the active profile).
 * - Cancels itself cleanly if the target profile/playlist has been deleted or disabled.
 * - Uses `NetworkType.CONNECTED`, `setRequiresBatteryNotLow(true)`, and exponential backoff retries.
 */
class PlaylistRefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val profileStore = ProfileStore(applicationContext)
        val requestedProfileId = inputData.getString(KEY_PROFILE_ID)?.takeIf { it.isNotBlank() }
            ?: profileStore.activeId()
        val requestedPlaylistId = inputData.getString(KEY_PLAYLIST_ID)?.takeIf { it.isNotBlank() }
            ?: requestedProfileId.orEmpty()

        val profile = profileStore.all().firstOrNull { it.id == requestedProfileId }
        if (profile == null) {
            if (!requestedProfileId.isNullOrBlank()) {
                cancelForPlaylist(applicationContext, requestedProfileId, requestedPlaylistId)
            }
            return@withContext Result.success()
        }

        val scope = profile.id
        val hours = profileStore.getAutoRefreshIntervalHours(scope)
        if (hours <= 0) {
            cancelForPlaylist(applicationContext, scope, requestedPlaylistId)
            return@withContext Result.success()
        }

        val cacheStore = ChannelCacheStore(applicationContext)
        try {
            when (profile.type) {
                ProfileType.M3U -> {
                    val url = profile.source.trim()
                    if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
                        profileStore.recordPlaylistRefreshResult(true, "Local M3U skipped in background", scope)
                        return@withContext Result.success()
                    }
                    val req = Request.Builder()
                        .url(url)
                        .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                        .build()
                    NetworkClient.apiClient.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
                        val body = resp.body ?: throw IllegalStateException("Empty response")
                        val parsed = BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { reader ->
                            M3uParser.parse(reader, maxChannels = 60_000, baseUrl = url)
                        }
                        if (parsed.isNotEmpty()) {
                            cacheStore.saveChannels(scope, parsed)
                            profileStore.recordPlaylistRefreshResult(true, "BG M3U (${profile.name}): ${parsed.size} ch", scope)
                        } else {
                            profileStore.recordPlaylistRefreshResult(false, "BG M3U (${profile.name}): 0 channels", scope)
                        }
                    }
                }
                ProfileType.XTREAM -> {
                    val creds = XtreamCredentials(profile.name, profile.source, profile.username, profile.password)
                    val repo = XtreamRepository()
                    val liveChannels = repo.fetchLiveStreams(creds).getOrThrow()
                    if (liveChannels.isNotEmpty()) {
                        cacheStore.saveChannels(scope, liveChannels)
                        profileStore.recordPlaylistRefreshResult(true, "BG Xtream (${profile.name}): ${liveChannels.size} Live", scope)
                    } else {
                        profileStore.recordPlaylistRefreshResult(false, "BG Xtream (${profile.name}): 0 Live", scope)
                    }
                }
            }
            profileStore.setNextScheduledRefreshEpochMs(System.currentTimeMillis() + hours * 3_600_000L, scope)
            Result.success()
        } catch (e: Exception) {
            Log.w("RAMPlayerWork", "BG refresh failed for $scope (attempt $runAttemptCount): ${e.message}")
            profileStore.recordPlaylistRefreshResult(false, "Retry $runAttemptCount: ${e.message ?: "Network error"}", scope)
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    companion object {
        const val KEY_PROFILE_ID = "profile_id"
        const val KEY_PLAYLIST_ID = "playlist_id"
        const val UNIQUE_WORK_NAME = "ram_player_periodic_playlist_refresh"

        fun uniqueWorkName(profileId: String, playlistId: String = profileId): String {
            val p = profileId.trim().replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "default" }
            val pl = playlistId.trim().replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { p }
            return "ram_player_refresh_${p}_${pl}"
        }

        fun scheduleForPlaylist(
            context: Context,
            profileId: String,
            playlistId: String = profileId,
            intervalHours: Int
        ) {
            val workName = uniqueWorkName(profileId, playlistId)
            val wm = WorkManager.getInstance(context.applicationContext)
            val store = ProfileStore(context.applicationContext)
            if (intervalHours <= 0) {
                wm.cancelUniqueWork(workName)
                store.setNextScheduledRefreshEpochMs(0L, profileId)
                return
            }
            val safeHours = intervalHours.coerceIn(1, 168).toLong()
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()
            val input = Data.Builder()
                .putString(KEY_PROFILE_ID, profileId)
                .putString(KEY_PLAYLIST_ID, playlistId)
                .build()
            val req = PeriodicWorkRequestBuilder<PlaylistRefreshWorker>(safeHours, TimeUnit.HOURS)
                .setConstraints(constraints)
                .setInputData(input)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
                .build()
            wm.enqueueUniquePeriodicWork(workName, ExistingPeriodicWorkPolicy.UPDATE, req)
            store.setNextScheduledRefreshEpochMs(System.currentTimeMillis() + safeHours * 3_600_000L, profileId)
        }

        fun cancelForPlaylist(context: Context, profileId: String, playlistId: String = profileId) {
            val workName = uniqueWorkName(profileId, playlistId)
            WorkManager.getInstance(context.applicationContext).cancelUniqueWork(workName)
            ProfileStore(context.applicationContext).setNextScheduledRefreshEpochMs(0L, profileId)
        }

        fun schedulePeriodicRefresh(context: Context, intervalHours: Int, accountScope: String) {
            scheduleForPlaylist(context, accountScope, accountScope, intervalHours)
        }

        fun cancelScheduledRefresh(context: Context, accountScope: String) {
            cancelForPlaylist(context, accountScope, accountScope)
        }
    }
}
