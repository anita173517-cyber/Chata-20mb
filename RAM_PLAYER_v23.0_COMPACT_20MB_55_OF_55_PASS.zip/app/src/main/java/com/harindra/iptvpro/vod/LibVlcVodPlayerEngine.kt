package com.harindra.iptvpro.vod

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.harindra.iptvpro.NetworkClient
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * RAM PLAYER v22.0 ULTIMATE — Genuine VideoLAN LibVLC 3.6.5 VOD Playback Engine.
 *
 * Replaces ExoPlayer for Movies & Series VOD playback while leaving Live TV Media3 100% untouched.
 * Features:
 * - Universal MKV/MP4/AVI/TS/HLS/DASH + H.264/HEVC/VP9 + AC3/E-AC3/DTS/TrueHD/AAC/Opus decoding
 * - Hardware decoding with instant Software (avcodec/FFmpeg) fallback
 * - Adaptive network caching cushion (2.5s / 5.0s / 10.0s) + HTTP reconnect
 * - True positive AND negative Audio Sync Delay (`setAudioDelay`) & Subtitle Sync Delay (`setSpuDelay`)
 * - Genuine 10-band Equalizer Cinema Dialogue & Voice Clarity presets without distortion
 * - Native embedded + external subtitle slave support (`IMedia.Slave.Type.Subtitle`)
 */
class LibVlcVodPlayerEngine(
    private val context: Context
) : VodPlayerEngine {

    override val engineName: String = "LibVLC 3.6.5 Cinema Engine"

    private val mainHandler = Handler(Looper.getMainLooper())
    private var libVlc: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private var attachedLayout: VLCVideoLayout? = null
    private var callbacks: VodEngineCallbacks? = null

    private var activeDecoderMode: VodDecoderMode = VodDecoderMode.AUTO_HW_FALLBACK
    private var activeBufferProfile: VodBufferProfile = VodBufferProfile.CINEMA_BALANCED
    private var pendingResumeMs: Long = 0L
    private var pendingResumeApplied: Boolean = false
    private var cachedPositionMs: Long = 0L
    private var cachedDurationMs: Long = 0L
    private var cachedBufferingPct: Float = 0f
    private var cachedSeekable: Boolean = false
    private var currentSpeed: Float = 1.0f
    private var currentVolumePct: Int = 100
    private var currentAudioDelayMs: Long = 0L
    private var currentSubtitleDelayMs: Long = 0L
    private var activeDialoguePreset: VodDialoguePreset = VodDialoguePreset.NORMAL

    override fun initialize(decoderMode: VodDecoderMode, bufferProfile: VodBufferProfile) {
        if (libVlc != null && mediaPlayer != null &&
            activeDecoderMode == decoderMode && activeBufferProfile == bufferProfile
        ) {
            return
        }
        val prevLayout = attachedLayout
        release()
        activeDecoderMode = decoderMode
        activeBufferProfile = bufferProfile

        val ua = NetworkClient.resolveEffectiveUserAgent(null)
        val options = ArrayList<String>().apply {
            add("--network-caching=${bufferProfile.networkCachingMs}")
            add("--file-caching=${bufferProfile.fileCachingMs}")
            add("--live-caching=${bufferProfile.networkCachingMs}")
            add("--clock-jitter=0")
            add("--clock-synchro=0")
            add("--drop-late-frames")
            add("--skip-frames")
            add("--http-reconnect")
            add("--http-user-agent=$ua")
            add("--avcodec-fast")
            add("--no-stats")
            add("--freetype-rel-fontsize=18")
            add("--freetype-outline-thickness=4")
        }

        val vlc = LibVLC(context.applicationContext, options)
        val mp = MediaPlayer(vlc)
        mp.setEventListener(vlcEventListener)
        libVlc = vlc
        mediaPlayer = mp

        if (prevLayout != null) {
            attachVideoLayout(prevLayout)
        }
    }

    fun attachVideoLayout(layout: VLCVideoLayout) {
        attachedLayout = layout
        mediaPlayer?.let { mp ->
            runCatching { mp.detachViews() }
            mp.attachViews(layout, null, true, false)
        }
    }

    fun detachVideoLayout() {
        runCatching { mediaPlayer?.detachViews() }
        attachedLayout = null
    }

    override fun setCallbacks(callbacks: VodEngineCallbacks?) {
        this.callbacks = callbacks
    }

    override fun loadMedia(
        streamUrl: String,
        resumePositionMs: Long,
        externalSubtitleUrl: String,
        headers: Map<String, String>
    ): Boolean {
        val cleanUrl = streamUrl.trim()
        if (cleanUrl.isEmpty() || (!cleanUrl.startsWith("http://", true) && !cleanUrl.startsWith("https://", true))) {
            return false
        }
        if (libVlc == null || mediaPlayer == null) {
            initialize(activeDecoderMode, activeBufferProfile)
        }
        val vlc = libVlc ?: return false
        val mp = mediaPlayer ?: return false

        pendingResumeMs = resumePositionMs.coerceAtLeast(0L)
        pendingResumeApplied = false
        cachedPositionMs = pendingResumeMs
        cachedDurationMs = 0L
        cachedBufferingPct = 0f

        val media = Media(vlc, Uri.parse(cleanUrl))
        when (activeDecoderMode) {
            VodDecoderMode.AUTO_HW_FALLBACK -> media.setHWDecoderEnabled(true, false)
            VodDecoderMode.HARDWARE_ONLY -> media.setHWDecoderEnabled(true, true)
            VodDecoderMode.SOFTWARE_ONLY -> media.setHWDecoderEnabled(false, false)
        }
        media.addOption(":network-caching=${activeBufferProfile.networkCachingMs}")
        media.addOption(":http-reconnect")
        val refHeader = headers["Referer"] ?: headers["referer"]
        if (!refHeader.isNullOrBlank()) {
            media.addOption(":http-referrer=$refHeader")
        }

        mp.setMedia(media)
        media.release()
        mp.play()
        mp.setRate(currentSpeed)
        applyDialoguePreset(activeDialoguePreset)

        val extSub = externalSubtitleUrl.trim()
        if (extSub.startsWith("http://", true) || extSub.startsWith("https://", true)) {
            addExternalSubtitle(extSub)
        }
        return true
    }

    private val vlcEventListener = MediaPlayer.EventListener { event ->
        when (event.type) {
            MediaPlayer.Event.Opening -> {
                mainHandler.post { callbacks?.onOpening() }
            }
            MediaPlayer.Event.Buffering -> {
                val pct = event.buffering
                cachedBufferingPct = pct
                mainHandler.post { callbacks?.onBuffering(pct) }
            }
            MediaPlayer.Event.Playing -> {
                if (pendingResumeMs > 10_000L && !pendingResumeApplied) {
                    pendingResumeApplied = true
                    mediaPlayer?.setTime(pendingResumeMs)
                }
                if (currentAudioDelayMs != 0L) {
                    mediaPlayer?.setAudioDelay(currentAudioDelayMs * 1000L)
                }
                if (currentSubtitleDelayMs != 0L) {
                    mediaPlayer?.setSpuDelay(currentSubtitleDelayMs * 1000L)
                }
                mainHandler.post {
                    callbacks?.onPlaying()
                    callbacks?.onTracksUpdated()
                }
            }
            MediaPlayer.Event.Paused -> {
                mainHandler.post { callbacks?.onPaused() }
            }
            MediaPlayer.Event.TimeChanged -> {
                val t = event.timeChanged.coerceAtLeast(0L)
                cachedPositionMs = t
                mainHandler.post { callbacks?.onTimeChanged(t) }
            }
            MediaPlayer.Event.LengthChanged -> {
                val l = event.lengthChanged.coerceAtLeast(0L)
                cachedDurationMs = l
                mainHandler.post { callbacks?.onLengthChanged(l) }
            }
            MediaPlayer.Event.SeekableChanged -> {
                cachedSeekable = event.seekable
                mainHandler.post { callbacks?.onSeekableChanged(event.seekable) }
            }
            MediaPlayer.Event.ESAdded,
            MediaPlayer.Event.ESSelected -> {
                mainHandler.post { callbacks?.onTracksUpdated() }
            }
            MediaPlayer.Event.EndReached -> {
                mainHandler.post { callbacks?.onEnded() }
            }
            MediaPlayer.Event.EncounteredError -> {
                mainHandler.post { callbacks?.onError("LibVLC encountered a playback or network error") }
            }
        }
    }

    override fun play() {
        mediaPlayer?.play()
    }

    override fun pause() {
        mediaPlayer?.pause()
    }

    override fun stop() {
        runCatching { mediaPlayer?.stop() }
    }

    override fun isPlaying(): Boolean = mediaPlayer?.isPlaying == true

    override fun isSeekable(): Boolean = mediaPlayer?.isSeekable ?: cachedSeekable

    override fun getPositionMs(): Long {
        val raw = mediaPlayer?.getTime() ?: -1L
        return if (raw >= 0L) raw else cachedPositionMs
    }

    override fun getDurationMs(): Long {
        val raw = mediaPlayer?.getLength() ?: -1L
        return if (raw > 0L) raw else cachedDurationMs
    }

    override fun getBufferedPercent(): Float = cachedBufferingPct

    override fun seekTo(positionMs: Long) {
        val dur = getDurationMs()
        val clamped = if (dur > 0L) positionMs.coerceIn(0L, dur) else positionMs.coerceAtLeast(0L)
        cachedPositionMs = clamped
        mediaPlayer?.setTime(clamped)
    }

    override fun setPlaybackSpeed(rate: Float) {
        currentSpeed = rate.coerceIn(0.5f, 2.0f)
        mediaPlayer?.setRate(currentSpeed)
    }

    override fun getPlaybackSpeed(): Float = currentSpeed

    override fun setVolumePercent(percent: Int) {
        currentVolumePct = percent.coerceIn(0, 150)
        mediaPlayer?.setVolume(currentVolumePct)
    }

    override fun getVolumePercent(): Int = currentVolumePct

    override fun setAudioDelayMs(delayMs: Long) {
        currentAudioDelayMs = delayMs.coerceIn(-5000L, 5000L)
        mediaPlayer?.setAudioDelay(currentAudioDelayMs * 1000L)
    }

    override fun getAudioDelayMs(): Long = currentAudioDelayMs

    override fun setSubtitleDelayMs(delayMs: Long) {
        currentSubtitleDelayMs = delayMs.coerceIn(-5000L, 5000L)
        mediaPlayer?.setSpuDelay(currentSubtitleDelayMs * 1000L)
    }

    override fun getSubtitleDelayMs(): Long = currentSubtitleDelayMs

    override fun getAudioTracks(): List<VodEngineTrack> {
        val mp = mediaPlayer ?: return emptyList()
        val selectedId = mp.getAudioTrack()
        val tracks = mp.getAudioTracks() ?: return emptyList()
        return tracks.map { td ->
            VodEngineTrack(
                id = td.id,
                name = td.name.orEmpty().ifBlank { "Audio Track ${td.id}" },
                isSelected = td.id == selectedId,
                isOffOption = td.id == -1
            )
        }
    }

    override fun selectAudioTrack(trackId: Int): Boolean {
        val mp = mediaPlayer ?: return false
        return mp.setAudioTrack(trackId)
    }

    override fun getSubtitleTracks(): List<VodEngineTrack> {
        val mp = mediaPlayer ?: return emptyList()
        val selectedId = mp.getSpuTrack()
        val tracks = mp.getSpuTracks() ?: return listOf(
            VodEngineTrack(id = -1, name = "Subtitles Off", isSelected = true, isOffOption = true)
        )
        return tracks.map { td ->
            val isOff = td.id == -1
            VodEngineTrack(
                id = td.id,
                name = if (isOff) "Subtitles Off" else td.name.orEmpty().ifBlank { "Subtitle ${td.id}" },
                isSelected = td.id == selectedId,
                isOffOption = isOff
            )
        }
    }

    override fun selectSubtitleTrack(trackId: Int): Boolean {
        val mp = mediaPlayer ?: return false
        return mp.setSpuTrack(trackId)
    }

    override fun addExternalSubtitle(subtitleUrl: String): Boolean {
        val mp = mediaPlayer ?: return false
        val clean = subtitleUrl.trim()
        if (clean.isEmpty()) return false
        return runCatching {
            mp.addSlave(IMedia.Slave.Type.Subtitle, Uri.parse(clean), true)
        }.getOrDefault(false)
    }

    override fun getVideoTracks(): List<VodEngineTrack> {
        val mp = mediaPlayer ?: return emptyList()
        val selectedId = mp.getVideoTrack()
        val tracks = mp.getVideoTracks() ?: return emptyList()
        return tracks.filter { it.id != -1 }.map { td ->
            VodEngineTrack(
                id = td.id,
                name = td.name.orEmpty().ifBlank { "Video Track ${td.id}" },
                isSelected = td.id == selectedId,
                isOffOption = false
            )
        }
    }

    override fun selectVideoTrack(trackId: Int): Boolean {
        val mp = mediaPlayer ?: return false
        return mp.setVideoTrack(trackId)
    }

    override fun getVideoInfo(): VodEngineVideoInfo {
        val mp = mediaPlayer ?: return VodEngineVideoInfo()
        val vt = runCatching { mp.getCurrentVideoTrack() }.getOrNull()
        val fps = if (vt != null && vt.frameRateDen > 0) {
            vt.frameRateNum.toFloat() / vt.frameRateDen.toFloat()
        } else 0f
        return VodEngineVideoInfo(
            width = vt?.width ?: 0,
            height = vt?.height ?: 0,
            fps = fps,
            codec = vt?.codec.orEmpty().ifBlank { "LibVLC" },
            bitrateBps = vt?.bitrate ?: 0,
            decoderModeLabel = activeDecoderMode.label
        )
    }

    override fun setAspectRatio(mode: VodAspectRatioMode) {
        val mp = mediaPlayer ?: return
        val scaleType = when (mode) {
            VodAspectRatioMode.FIT -> MediaPlayer.ScaleType.SURFACE_BEST_FIT
            VodAspectRatioMode.FILL -> MediaPlayer.ScaleType.SURFACE_FIT_SCREEN
            VodAspectRatioMode.ZOOM -> MediaPlayer.ScaleType.SURFACE_FILL
            VodAspectRatioMode.STRETCH -> MediaPlayer.ScaleType.SURFACE_16_9
            VodAspectRatioMode.ORIGINAL -> MediaPlayer.ScaleType.SURFACE_ORIGINAL
        }
        mp.setVideoScale(scaleType)
    }

    override fun applyDialoguePreset(preset: VodDialoguePreset) {
        activeDialoguePreset = preset
        val mp = mediaPlayer ?: return
        setVolumePercent(preset.volumePercent)
        runCatching {
            if (preset == VodDialoguePreset.NORMAL) {
                mp.setEqualizer(null)
            } else {
                val eq = MediaPlayer.Equalizer.create()
                eq.setPreAmp(preset.preampDb)
                // LibVLC 10-band EQ: bands 4 (600Hz), 5 (1kHz), 6 (3kHz) are human voice clarity bands
                if (preset == VodDialoguePreset.NIGHT_WHISPER) {
                    eq.setAmp(0, -4.0f) // reduce sub-bass rumble at night
                    eq.setAmp(1, -3.0f)
                }
                eq.setAmp(4, preset.voiceMidBoostDb * 0.7f)
                eq.setAmp(5, preset.voiceMidBoostDb)
                eq.setAmp(6, preset.voiceMidBoostDb * 0.8f)
                mp.setEqualizer(eq)
            }
        }
    }

    override fun release() {
        mainHandler.removeCallbacksAndMessages(null)
        runCatching {
            mediaPlayer?.setEventListener(null)
            mediaPlayer?.stop()
            mediaPlayer?.detachViews()
            mediaPlayer?.release()
        }
        mediaPlayer = null
        runCatching { libVlc?.release() }
        libVlc = null
    }
}
