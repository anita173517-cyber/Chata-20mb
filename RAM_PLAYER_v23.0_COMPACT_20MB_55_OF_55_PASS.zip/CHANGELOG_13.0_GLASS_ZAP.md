# 13.0 Glass-Zap — low-RAM stability upgrade

- Preserved the supplied 4D Glossy Studio layered UI and all existing player features.
- Removed `android:largeHeap`; the platform's normal memory policy is preferable on a 512MB TV.
- Platform decoders preferred; optional extension decoder loading disabled, decoder fallback retained.
- Tuned the low-memory buffer profile to reduce ultra-short-threshold rebuffer risk.
- Next-channel-only socket warmup; recent/favorite speculative warmup removed from the playback-ready path.
- Individual prefetch request capped at 1.8 seconds and 128 bytes.
- GitHub Actions now extracts the source ZIP deterministically, provisions Android SDK 36, verifies, tests, and assembles one release APK.
